﻿public enum ListShowType
{
    Text,//y
    Link,//y
    BoundLink,//y
    ConfirmLink,//y
    BoolLink,//y
    Pic,//y
    Foreign,//y
    Hidden,
    //Order,
    Template//---
}
public enum EditShowType
{
    Text,//y
    DateTime,//y
    MultiText,//y
    Editor,//y
    picUpload,//y
    docUpload,//y
    DropDownList,//y
    CheckList,//y
    Check,//y
    RadioList,//y
    Hidden,
    Template//y
}